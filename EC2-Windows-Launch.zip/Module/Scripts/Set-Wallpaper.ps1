<#-----------------------------------------------------------------------------------------------------------
    Set-Wallpaper sets the instance information on current wallpaper.
    If not wallpaper is set, it creates one with custom color.
-------------------------------------------------------------------------------------------------------------#>
function Set-Wallpaper
{
  param(
    [Parameter(Position = 0)]
    [switch]$Initial
  )

  if (Test-NanoServer)
  {
    return
  }

  # Before calling any function, initialize the log with the file name.
  # WallpaperSetup.log requires that standard user accounts have write access.
  # Upon login for each user, the wallpaper script runs with that user's access permissions.
  Initialize-Log -FileName "WallpaperSetup.log" -AllowStandardUserWrite $true

  Write-Log "Begin wallpaper set up."
  Write-Log "Get instance information to render on the wallpaper."

  # Import the wallpaper utility methods.
  Import-WallpaperUtil

  # Keep both original wallpaper and modified wallpaper in the following directories.
  $originalWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:originalWallpaperName
  $customWallpaperPath = Join-Path $env:LOCALAPPDATA -ChildPath $script:customWallpaperName

  # Get the current wallpaper path.
  $currentWallpaperPath = [WallpaperUtil.Helper]::GetWallpaper()
  if ($currentWallpaperPath -eq "(None)")
  {
    $currentWallpaperPath = ""
  }

  enum WallpaperCustomizationAction
  {
    DoNothing
    UseSolidColor
    UseOriginalImage
  }

  function Resolve-WallpaperCustomizationAction
  {
    param([bool]$InitialSetup)
    # Initial wallpaper setup was indicated. By default this only runs the first time a user logs in on a new instance.
    if ($InitialSetup)
    {
      # The current wallpaper path is blank, the wallpaper file does not exist, or the wallpaper is set to the custom wallpaper path (user has manually
      # invoked with the Initial flag or it was set on a previous instance and not cleared by sysprep or Clear-Wallpaper).
      if ([string]::IsNullOrEmpty($currentWallpaperPath) -or (-not (Test-Path $currentWallpaperPath)) -or $currentWallpaperPath -ieq $customWallpaperPath)
      {
        # If the original wallpaper path exists, use it to customize with current text.
        if (Test-Path $originalWallpaperPath)
        {
          return [WallpaperCustomizationAction]::UseOriginalImage
        }
        # Otherwise use a solid color with the current text.
        return [WallpaperCustomizationAction]::UseSolidColor
      }

      # The current wallpaper has the same name as the generated custom wallpaper but is located elsewhere.
      if ((Get-Item $currentWallpaperPath).Name -eq $script:customWallpaperName)
      {
        # The original wallpaper is located in the same folder as the customized wallpaper.
        $assumedOriginalWallpaperPath = Join-Path (Get-Item $currentWallpaperPath).Directory.FullName -ChildPath $script:originalWallpaperName
        if (Test-Path $assumedOriginalWallpaperPath)
        {
          # Copy the assumed original wallpaper to the user's profile to save it for future instance launches.
          Copy-Item -Path $assumedOriginalWallpaperPath -Destination $originalWallpaperPath -Force
          return [WallpaperCustomizationAction]::UseOriginalImage
        }
        return [WallpaperCustomizationAction]::UseSolidColor
      }

      # Copy the current wallpaper to the user's profile to save it for future instance launches.
      Copy-Item -Path $currentWallpaperPath -Destination $originalWallpaperPath -Force
      return [WallpaperCustomizationAction]::UseOriginalImage
    }

    # The current wallpaper is still the previously generated custom wallpaper and the original wallpaper is still present.
    if ($currentWallpaperPath -ieq $customWallpaperPath)
    {
      if (Test-Path $originalWallpaperPath)
      {
        # Use the original wallpaper image and customize with current text.
        return [WallpaperCustomizationAction]::UseOriginalImage
      }
      Write-Log ("Original wallpaper is missing: {0}" -f $originalWallpaperPath)
      return [WallpaperCustomizationAction]::DoNothing
    }

    # Test if the user has manually set their wallpaper away from the customized wallpaper.
    if ($currentWallpaperPath -ne $customWallpaperPath)
    {
      # Delete the wallpaper setup file in the current user's startup directory so wallpaper customization will cease.
      $userStartupPath = "C:\Users\{0}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -f $env:USERNAME
      $wallpaperSetupPath = Join-Path $userStartupPath -ChildPath $script:wallpaperSetupName

      if (Test-Path $wallpaperSetupPath)
      {
        Remove-Item -Path $wallpaperSetupPath -Force -Confirm:$false
      }

      if (Test-Path $customWallpaperPath)
      {
        # Also delete the custom wallpaper for the current user.
        Remove-Item -Path $customWallpaperPath -Force -Confirm:$false
      }
    }

    return [WallpaperCustomizationAction]::DoNothing
  }

  $action = Resolve-WallpaperCustomizationAction -InitialSetup $Initial.IsPresent
  if ($action -eq [WallpaperCustomizationAction]::DoNothing)
  {
    Write-Log "Skipping wallpaper customization."
    return
  }

  # Some information is retrieved from metadata.
  $metadata = @(
    @{ Name = "Instance ID"; Source = "meta-data/instance-id" }
    @{ Name = "Public IPv4 address"; Source = "meta-data/public-ipv4" }
    @{ Name = "Private IPv4 address"; Source = "meta-data/local-ipv4" }
    @{ Name = "IPv6 address"; Source = "meta-data/ipv6" }
    @{ Name = "Instance size"; Source = "meta-data/instance-type" }
    @{ Name = "Availability Zone"; Source = "meta-data/placement/availability-zone" }
  )

  $infos = @()
  $instanceSize = ""

  # Get current hostname.
  $infos += "Hostname: {0}" -f [System.Net.Dns]::GetHostName()

  # Get each information from metadata list defined above.
  foreach ($data in $metadata)
  {
    try
    {
      $value = (Get-Metadata -UrlFragment $data.Source).Trim()
      $infos += "{0}: {1}" -f $data.Name,$value

      if ($data.Name -eq "Instance Size")
      {
        $instanceSize = $value
      }

      Write-Log ("Successfully retrieved {0} from metadata" -f $data.Name)
    }
    catch
    {
      Write-Log ("Failed to retrieve {0} from metadata: {1}" -f $data.Name,$_.Exception.Message)
    }
  }

  # Get architecture chip information from registry key.
  $envRegRes = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -ErrorAction SilentlyContinue
  if ($envRegRes -and $envRegRes.PROCESSOR_ARCHITECTURE)
  {
    $infos += "Architecture: {0}" -f $envRegRes.PROCESSOR_ARCHITECTURE
    Write-Log ("Successfully retrieved architecture chip from registry key")
  }
  else
  {
    Write-Log "Failed to retrieve architecture chip from registry key"
  }

  # Set instance type information if instance size was found from metadata above
  if ($instanceSize)
  {
    try
    {
      $instanceType = GetInstanceTypeDetails $instanceSize

      if ($instanceType)
      {
        $infos += "Total memory: {0}" -f $instanceType.Memory
        $infos += "Network: {0}" -f $instanceType.NetworkPerformance
        Write-Log ("Successfully found instance type information for instance size {0}" -f $instanceSize)
      }
      else
      {
        Write-Log ("Failed to find instance type information for instance size {0}" -f $instanceSize)
      }
    }
    catch
    {
      Write-Log ("Failed to find instance type information for instance size {0}: {1}" -f $instanceSize,$_.Exception.Message)
    }
  }

  # Check if message contains any information about the instance
  if ($infos.Length -eq 0)
  {
    throw New-Object System.Exception ("Failed to get instance information.")
  }

  # Create a message from the infos
  $message = ""
  foreach ($info in $infos)
  {
    $message += $info + [Environment]::NewLine
  }

  Write-Log ("Retrieved the following information to display on the wallpaper: {{{0}{1}}}" -f [Environment]::NewLine,$message)

  try
  {
    Add-Type -AssemblyName System.Windows.Forms

    $fontStyle = "Calibri"
    $fontSize = 12

    Write-Log "Rendering instance information on wallpaper"

    $width = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Width
    $height = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Height

    $textfont = New-Object System.Drawing.Font ($fontStyle,$fontSize,[System.Drawing.FontStyle]::Regular)
    $textBrush = New-Object Drawing.SolidBrush ([System.Drawing.Color]::White)

    $proposedSize = New-Object System.Drawing.Size ([int]$width,[int]$height)
    $messageSize = [System.Windows.Forms.TextRenderer]::MeasureText($message,$textfont,$proposedSize)

    if ($action -eq [WallpaperCustomizationAction]::UseSolidColor)
    {
      # Check and create a new wallpaper if no wallpaper is set in current system.
      Write-Log "No wallpaper is set.. Setting wallpaper with custom color"
      $bgrRectangle = New-Object Drawing.Rectangle (0,0,[int]$width,[int]$height)
      $bgrBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::Navy)
      $bmp = New-Object System.Drawing.Bitmap ([int]$width,[int]$height)
      $graphics = [System.Drawing.Graphics]::FromImage($bmp)
      $graphics.FillRectangle($bgrBrush,$bgrRectangle)
    }
    else #[WallpaperCustomizationAction]::UseOriginalImage
    {
      # Get the bitmap from the current wallpaper and set the size to be fit in screen.
      Write-Log "Wallpaper found.. Rendering instance information on current wallpaper"
      $srcBmp = [System.Drawing.Bitmap]::FromFile($originalWallpaperPath)
      $bmp = New-Object System.Drawing.Bitmap ($srcBmp,$width,$height)
      $graphics = [System.Drawing.Graphics]::FromImage($bmp)
      $srcBmp.Dispose()
    }

    # Set the position and size of the text box with rectangle.
    $rec = New-Object System.Drawing.RectangleF (($width - $messageSize.Width - 20),30,($messageSize.Width + 20),$messageSize.Height)
    $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
    $graphics.DrawString($message,$textfont,$textBrush,$rec)

    # Save the new wallpaper in destination defined above.
    $bmp.Save($customWallpaperPath,[System.Drawing.Imaging.ImageFormat]::Jpeg)

    # Finally, set the wallpaper!
    [WallpaperUtil.Helper]::SetWallpaper($customWallpaperPath)

    Write-Log "Successfully rendered instance information on wallpaper"
  }
  catch
  {
    Write-Log ("Failed to render instance information on wallpaper {0}" -f $_.Exception.Message)
  }
  finally
  {
    if ($graphics)
    {
      $graphics.Dispose()
    }
    if ($bmp)
    {
      $bmp.Dispose()
    }
  }

  # Before finishing the script, complete the log.
  Complete-Log
}

# SIG # Begin signature block
# MIIurgYJKoZIhvcNAQcCoIIunzCCLpsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBgQ5KG3hplcuXA
# hb+sYvI9w8u4rTqeQHAVoUXDCKLHUqCCE+MwggXAMIIEqKADAgECAhAP0bvKeWvX
# +N1MguEKmpYxMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMjIwMTEz
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBZjCCAWIwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUsT7DaQP4v0cB1JgmGggC72NkK8MwDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAC
# hj1odHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJh
# bmNlRVZSb290Q0EuY3J0MEsGA1UdHwREMEIwQKA+oDyGOmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwHAYD
# VR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQELBQADggEBAEHx
# qRH0DxNHecllao3A7pgEpMbjDPKisedfYk/ak1k2zfIe4R7sD+EbP5HU5A/C5pg0
# /xkPZigfT2IxpCrhKhO61z7H0ZL+q93fqpgzRh9Onr3g7QdG64AupP2uU7SkwaT1
# IY1rzAGt9Rnu15ClMlIr28xzDxj4+87eg3Gn77tRWwR2L62t0+od/P1Tk+WMieNg
# GbngLyOOLFxJy34riDkruQZhiPOuAnZ2dMFkkbiJUZflhX0901emWG4f7vtpYeJa
# 3Cgh6GO6Ps9W7Zrk9wXqyvPsEt84zdp7PiuTUy9cUQBY3pBIowrHC/Q7bVUx8ALM
# R3eWUaNetbxcyEMRoacwggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdnMIIFT6ADAgECAhAIaSgnopDAtpU2nRSjj8m1MA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjUwODA0MDAwMDAwWhcNMjYwODAzMjM1OTU5WjCB7zET
# MBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQxNTI5NTQx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdTZWF0
# dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMRAwDgYDVQQL
# EwdBV1MgRUMyMSIwIAYDVQQDExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMIIB
# ojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA09z6LRLZ6B29Vw2rlhoClpGs
# KaHQgVSWBiQsZoosPwxMx7nOp3AC4aRP4V7v8E8e1zmzvevPdVL/p9KSPvFz4ApF
# Lt4c5xDryw+bn053Dy6eiKvmiOetjTuP/3b49H4R6kt8LZ8x5KhaphgypeIHKQHC
# 3JrfDjCq3Zh+WYMvL5O2fwcaMQQunl1AiXXKAfahflmC2r0GYzNthvqXvBkfAs9F
# e6ivOSLGVxrtptGveY8omIrde1vVFWItRww+Lk1yxXN5zO28M5SsDMJ5eryZPQ3y
# CWc0722z2GJJ7horCYpWqz9swuVd/YArwtk/Fmbwr8K+A7ZIbM0dLHPx20K3+r/n
# dNyO0gd0G8HGEMbTuE8zG0gPcOLn8faWM7W1pMmkiuOL8WUa2B/Pd0xJw5WinHhj
# FEyGB3LKPEZbxa/IIfHcbqPNE9tLJYJWZ9t9Cg10fECSJ+xsNEeLwerLkZaEzs/H
# fimTNMa/5SuWjCES/e3QUOIm2kg1TO7mXSdAljhtAgMBAAGjggICMIIB/jAfBgNV
# HSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQU6KNonE+tTU2/
# W3Q6S4Ynvfd8w3IwPQYDVR0gBDYwNDAyBgVngQwBAzApMCcGCCsGAQUFBwIBFhto
# dHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5
# NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIx
# Q0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFx4M
# +HScolpI7T6bQYaAO4SU9rP1qiJxBSzEZ7j9rr0Jv3qdBm0SF7iB5NMBmgAKFRnn
# Wb0D46Da1q4hKlC4b9GX7oO6DLiA4b6upXn4ARULR8B+zMaC3PIXLemcnu1ENkj4
# UeFzIaxPbpeT5mNUT8D5dWDsO4L712KN0gkbtt+rwF5cowDuv6ei1A17HHkPPP1D
# KELMP2u5CGrjn67HuNv6n4+gHJW1CP0NSCyB2LpEZf/2FFiqfz4cpCYh6S81/ziA
# cvchuWGSxNpcGRmZFwAcd7wQcNveTJW9YE0JIJApE/q7EsLmk2pyYk02beNXedRN
# fVE7HMLb9ll706RZT93oMdJpfKVHq1qCLsIz/CChcBd4mHsStvxtj9cVCTlE7ELw
# g44I0sZQ+AITXgon+86fyjEM1G4SsZWcnhu8A9U2QzsfvD8vCkuHi3CnEeztf/u2
# 87tzprVnbz0/Y+DmOetj+CmdzNR0949irc10C2ikfK6dWt5r46bzHNYnHEhTVafX
# HL6zHhjOO4liSDb9yP4085xWnjAn4i0NpvL3uHb3Q4NrTrjJQtekVpIBbPuPsF4w
# a/uGLkDjeqjU3CJ9BifbYXHYZNw4ZJz+l5VGFU7RlABPgUIj4Fmac0ZnmbRemFQ8
# I3WQSlfftfuWwHUJ0NkQ/kEl47ZXRNyVfVEuLDYxghohMIIaHQIBATB9MGkxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGln
# aUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAy
# MSBDQTECEAhpKCeikMC2lTadFKOPybUwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEE
# AYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgs9HKOKJXZhxLggV7
# K4QcCg7caVAGzs30uONKMpgasQgwDQYJKoZIhvcNAQEBBQAEggGAZVajvqVsc5Ce
# z5YWvyaKucxnukDpmmB5m4UEYoe6GuoGQGHciNJp1w6aWSb4A2khGnRMoqrGyo88
# Jzba4V4x46a6nNpz4vnnykt2rSKbgYvytF0D7nB/PqzZH/ver0lXU/tbDoSGfApG
# ASE0HRTXenMG0N+8XTZT1RdbCT7As8/qYUYaG6QrkHtly8AkpQ74oD5q1rwndNjZ
# jP+dvfDlL1UsAKZzwMDr4DmjaWbUwlEQirhcGp5oZlg/WZDM0YPn4EENLuua5hxT
# jpNixbARDbgPeNMAsjq0WVX1WbkZp3f9axaoBryLIf55jRHe713Lu02SmHrhIbWa
# xn3ElGSUktEGaTPFWcz7I0JaF1RQCvd/Yb7jXKPf0DtEHzqE3XR+ivnPfEo4ajCm
# sivujzgjfMQWvndxXJVWaMF3c7rN288JT7ryg1cPMFzYhJzdQIPQvOR5A3Hc6GJe
# WqMS6Br3Rx8twtt9mwbZf249aNvaw+a2OTAywwH9TaS72vZUOYx9oYIXdzCCF3MG
# CisGAQQBgjcDAwExghdjMIIXXwYJKoZIhvcNAQcCoIIXUDCCF0wCAQMxDzANBglg
# hkgBZQMEAgEFADB4BgsqhkiG9w0BCRABBKBpBGcwZQIBAQYJYIZIAYb9bAcBMDEw
# DQYJYIZIAWUDBAIBBQAEIEoO1UVC0O0mep1W+7U0eNVyRnnjF2dsLRy2UlOQAYDF
# AhEAku79NAsyjTrF1C2VXGHOOBgPMjAyNTEwMTMwNTIxMDFaoIITOjCCBu0wggTV
# oAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENB
# MTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgU0hB
# MjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwtEsae0OquYFazK1e6b1H/hnAKAd/K
# N8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjni6bz52fGTfr6PHRNv6T7zsf1Y/E3
# IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EIYLkrLKd6qJnuzK8Vcn0DvbDMemQF
# oxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytxNM89PZXUP/5wWWURK+IfxiOg8W9l
# KMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6EYevvOi7XOc4
# zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Oskkkrvt6lPAw/p4oDSRZreiwB7x9y
# krjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw4Smz8U07hqF+
# 8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrAtuvz0D3T+dYaNcwafsVCGZKUhQPL
# 1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi54wm0i2ePZD5pPIssoszQyF4//3D
# oK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJYi+6I03UuT1j7FnrqVrOzaQoVJOee
# StPeldYRNMmSF3voIgMFtNGh86w3ISHNm0IaadCKCkUe2LnwJKa8TIlwCUNVwppw
# n4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQU5Dv8
# 8jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgwFoAU729TSunkBnx6yuKQVvYv1Ens
# y04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIGVBggr
# BgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5j
# cnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEu
# Y3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0B
# AQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNAciH45PYiT9s1i6UKtW+FERp8FgXR
# GQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PCvHpQuPqFgqp1
# PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5qjzvZs7JIIgt0GCFD9ktx0LxxtRQ
# 7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kzekd8oEARzFAWgeW3az2xejEWLNN4e
# KGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE2oi0fcI8VMbt
# oRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLhAezu/3Lr00Gr
# JzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2/gTlQJINqDr6
# JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCyIaehr0XkBoDI
# GMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53VJUNOaMWMts0VlRYxe5nK+At+DI96
# HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yERNpbJCjyCYG2j+bdpxo/1Cy4uPcU3
# AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3zWcwgga0MIIE
# nKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNV
# BAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdp
# Y2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0y
# NTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYD
# VQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBH
# NCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51N
# rY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5ba
# p+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf7
# 7S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF
# 2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80Fio
# cSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzV
# yhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl
# 92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGP
# RdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//
# Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4O
# Lu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM
# 7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# ABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM
# 0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqW
# Gd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr
# 0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35
# k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKq
# MVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiy
# fTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDU
# phPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTj
# d6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2Z
# yJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWC
# nb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZPubdcMIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDfDCCA3gCAQEwfTBpMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0
# ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAKgO8Y
# S43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsq
# hkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjUxMDEzMDUyMTAxWjArBgsqhkiG
# 9w0BCRACDDEcMBowGDAWBBTdYjCshgotMGvaOLFoeVIwB/tBfjAvBgkqhkiG9w0B
# CQQxIgQgKdXLA9+X5PkbQAUr2HM2UKoPV+Ts6693GSatyoys40MwNwYLKoZIhvcN
# AQkQAi8xKDAmMCQwIgQgSqA/oizXXITFXJOPgo5na5yuyrM/420mmqM08UYRCjMw
# DQYJKoZIhvcNAQEBBQAEggIAl4WpVWvgkdRa2KLb6vPOuvr8HnyRjpED+6bm46qt
# NCPWhj8Kr8ev9NGyIP+z+sGYrlSau48hDcbEKWTcVT26RjpY4lmb+JTf1sBqyaeT
# kjRpzM2iSNLfgbke3vyG9Nu2d/g/R7sA42Ve4Z7hjhZohr9lF3Zcl5Dj9ZK7ez6P
# GiJB+fRIPekka0i1whw9dnDesh3B7LSOrhG946m/OZNLytKfEXaHCW2QQIRP4O6j
# +ASaLL6t5V/2SDrIY0si2WctyULy8qZxWvzrxuJKdKv6UL5bCXIy1g0I2IYo72ks
# ncVVQTQsvqle3U1gH0I4UxNw3t81UgOWJmIKWmjcptctTOnchZsu4Jg7qkJgx0TJ
# s5g3pZEbK6Bqj20Pyg+lUKR6166MZWi2BTvZ72w9LDG9ZdBflltuXLewYDZxCZXp
# 6gBX6tZMLSzAIef//QyvyVUKDMnL4IRGN2lRvSxU0zWdNdJbDuSi99N2SIw6fbRz
# EdQvFNiU0T8MWfXjazj5wc49usl4tL6CwJz797KVthPiGqjVtMt2qieNcY+yB5HJ
# rf+0AxGl8phr+iSPxtdpOue4qbgi459r84IgZ0CsWK9spm2lSBaZPWRDjLtPadSv
# os+hREt9dhB8j2+bcf5tILAdZfs+uNCh4nfQnbPlso5l9SAmXWdh2Q2J5SrifzyC
# xGg=
# SIG # End signature block
