function Get-HttpBinaryFile ($url,$proxy,$file)
{
  try
  {
    $webProxy = New-Object System.Net.WebProxy ($proxy,$false)
    $request = [System.Net.WebRequest]::Create($url)
    $request.Timeout = "120000"
    $request.Proxy = $webProxy
    $response = $request.GetResponse()
    $statusCode = ($response.StatusCode) -as [int]

    if ($statusCode -ne "200")
    {
      return $false;
    }

    $stream = $response.GetResponseStream()
    $ms = New-Object System.IO.MemoryStream

    $stream.CopyTo($ms)

    $data = $ms.ToArray()

    [System.IO.File]::WriteAllBytes($file,$data)

    return $true
  }
  catch
  {
    return $false;
  }
}

function Send-HttpPostJson ($url,$proxy,$json)
{
  try
  {
    $webProxy = New-Object System.Net.WebProxy ($proxy,$false)
    $request = [System.Net.WebRequest]::Create($url)
    $request.Method = "POST"
    $request.ContentType = 'application/json; charset=utf-8'
    $request.Proxy = $webProxy

    $stream = $request.GetRequestStream()
    $streamWriter = New-Object System.IO.StreamWriter ($stream)
    $streamWriter.Write($json)
    $streamWriter.Dispose();
    $stream.Dispose();

    $request.Timeout = "20000"
    $response = $request.GetResponse()
    $statusCode = ($response.StatusCode) -as [int]

    if ($statusCode -ne "200")
    {
      return $null;
    }

    $reqstream = $response.GetResponseStream()
    $sr = New-Object System.IO.StreamReader $reqstream
    $result = $sr.ReadToEnd()
    return $result
  }
  catch
  {
    return $null;
  }
}

function Pop-DnLexerChar ([System.Text.StringBuilder]$dn)
{
  if ($dn.Length -gt 0)
  {
    $res = Read-DnLexerChar $dn
    [void]$dn.Remove([int]0,[int]1)
    return $res
  }
  throw "Invalid DN - unexpected end"
}

function Read-DnLexerChar ([System.Text.StringBuilder]$dn)
{
  if ($dn.Length -gt 0)
  {
    [char[]]$arr = 'c'
    [void]$dn.CopyTo(0,$arr,0,1)

    return $arr[0]
  }
  return '`0'
}

function Skip-DnLexerWhitespace ([System.Text.StringBuilder]$dn)
{
  while ($true)
  {
    $c = Read-DnLexerChar $dn
    if ($c -eq '`0' -or ![System.Char]::IsWhiteSpace($c))
    {
      break
    }
    [void](Pop-DnLexerChar $dn)
  }
}

function Skip-DnLexerToCommaOrSemicolon ([System.Text.StringBuilder]$dn)
{
  while ($true)
  {
    $c = Read-DnLexerChar $dn
    if ($c -eq ',' -or $c -eq ';')
    {
      [void](Pop-DnLexerChar $dn)
      break
    }
    if ($c -eq '`0')
    {
      break
    }
    if (![System.Char]::IsWhiteSpace($c))
    {
      throw "Unexpected character when comma was expected"
    }
    [void](Pop-DnLexerChar $dn)
  }
}

function Read-DnAttributeKey ([System.Text.StringBuilder]$dn)
{
  Skip-DnLexerWhitespace $dn
  if ((Read-DnLexerChar $dn) -eq '`0')
  {
    return $null
  }

  $attrkey = ""
  for ($c = (Pop-DnLexerChar $dn); $c -ne '=' -and $c -ne '+'; $c = (Pop-DnLexerChar $dn))
  {
    $attrkey = $attrkey + $c
  }

  $attrkey = $attrkey.Trim().ToUpper()

  if ($attrkey.Length -eq 0)
  {
    throw "Invalid DN - empty attribute key"
  }

  return $attrkey
}

function Read-DnAttributeValue ([System.Text.StringBuilder]$dn)
{
  [void](Skip-DnLexerWhitespace $dn)

  if ((Read-DnLexerChar $dn) -eq '"')
  {
    [void](Pop-DnLexerChar $dn)
    $val = Read-DnAttributeValueWithTerminator $dn '"' '"'
    [void](Skip-DnLexerToCommaOrSemicolon $dn)
    return $val
  }

  return Read-DnAttributeValueWithTerminator $dn ',' ';'
}

function Test-DnLexerIsHexDigit ($escaped)
{
  if ([System.Char]::IsDigit($escaped))
  {
    return $true
  }
  if ($escaped -ge 'a' -and $escaped -le 'f')
  {
    return $true
  }
  if ($escaped -ge 'A' -and $escaped -le 'F')
  {
    return $true
  }
  return $false
}

function Add-DnLexerPendingWhitespaceToBytestream ([System.Collections.Generic.List[System.Byte]]$byteStream,[System.String]$pendingWhitespace)
{
  if ($pendingWhitespace.Length -gt 0)
  {
    $byteStream.AddRange([System.Text.Encoding]::UTF8.GetBytes($pendingWhitespace))
  }

  return ''
}

function Add-DnLexerBytestream ([System.Collections.Generic.List[System.Byte]]$byteStream,[System.Char]$c)
{
  if ($c -le 0x7f)
  {
    $byteStream.Add($c)
  }
  else
  {
    $byteStream.AddRange([System.Text.Encoding]::UTF8.GetBytes($c))
  }
}

function Read-DnAttributeValueWithTerminator ([System.Text.StringBuilder]$dn,$terminator1,$terminator2)
{
  [System.Collections.Generic.List[System.Byte]]$byteStream = (New-Object System.Collections.Generic.List[System.Byte])
  [string]$accumulatedWhitespace = ''

  while ((Read-DnLexerChar $dn) -ne '`0')
  {
    $c = Pop-DnLexerChar $dn

    if ($c -eq $terminator1 -or $c -eq $terminator2)
    {
      break
    }

    if ($c -eq '\')
    {
      $escaped = Pop-DnLexerChar $dn

      $accumulatedWhitespace = Add-DnLexerPendingWhitespaceToBytestream $byteStream $accumulatedWhitespace

      if ((Test-DnLexerIsHexDigit $escaped))
      {
        $next = Pop-DnLexerChar $dn
        $hex = "" + $escaped + $next
        $byteStream.Add([System.Byte]::Parse($hex,[System.Globalization.NumberStyles]::HexNumber))
      }
      else
      {
        Add-DnLexerBytestream $byteStream $escaped
      }
    }
    elseif ([System.Char]::IsWhiteSpace($c))
    {
      $accumulatedWhitespace += $c
    }
    else
    {
      $accumulatedWhitespace = Add-DnLexerPendingWhitespaceToBytestream $byteStream $accumulatedWhitespace
      Add-DnLexerBytestream $byteStream $c
    }
  }

  $str = [System.Text.Encoding]::UTF8.GetString($byteStream.ToArray())
  return $str
}

function Read-DistinguishedName ($rdn)
{
  [System.Text.StringBuilder]$dn = New-Object System.Text.StringBuilder
  [void]$dn.Append($rdn)

  $result = @{}

  while ($dn.Length -gt 0)
  {
    $key = Read-DnAttributeKey $dn
    $value = Read-DnAttributeValue $dn

    if ($null -eq $key) {
      continue
    }

    [void]$result.Add($key,$value)
    [void](Skip-DnLexerWhitespace $dn)
  }
  return $result
}

function Test-DnConstraints ($rdn,$constraints)
{
  [System.Collections.Hashtable]$constr = Read-DistinguishedName $constraints
  [System.Collections.Hashtable]$subj = Read-DistinguishedName $rdn

  foreach ($kvp in $constr.GetEnumerator())
  {
    if ($subj.ContainsKey($kvp.Key))
    {
      if ($subj[$kvp.Key] -ne $kvp.Value)
      {
        [System.Console]::WriteLine("Signature check failed : '$($subj[$kvp.Key])' != '$($kvp.Value)'")
        return $false
      }
    }
    else
    {
      [System.Console]::WriteLine("Signature check failed : $($kvp.Key) field missing")
      return $false
    }
  }

  return $true
}

function Test-CertificateIsAws ($file)
{
  $auth = Get-AuthenticodeSignature $file
  $subj = $auth.SignerCertificate.Subject

  $dnAws = "CN=`"Amazon Web Services, Inc.`", O=`"Amazon Web Services, Inc.`", L=Seattle, S=Washington, C=US"
  $dnAmzn = "CN=Amazon Services LLC, OU=Software Services, O=Amazon Services LLC, L=Seattle, S=Washington, C=US"

  return ($auth.Status -eq "Valid") -and ((Test-DnConstraints $subj $dnAws) -or (Test-DnConstraints $subj $dnAmzn))
}

function Get-EgpuSoftwareVersion ($key)
{
  try
  {
    $item = Get-ItemProperty -Path ("HKLM:\SOFTWARE\Amazon\EC2ElasticGPUs\$key") -ErrorAction "Ignore"

    if ($null -eq $item)
    {
      return $null
    }

    return $item.Version
  }
  catch
  {
    return $null
  }
}

function Install-EgpuManager ()
{
  try
  {

    $installedVer = Get-EgpuSoftwareVersion "EC2ElasticGPUs_Manager"

    if (($null -ne $installedVer) -and ($installedVer -ne ""))
    {
      Write-Log "ElasticGPU already installed - version $installedVer"
      return $null
    }

    $metadataAvailable = Get-Metadata -UrlFragment "meta-data"

    if ($null -eq $metadataAvailable)
    {
      Write-ErrorLog "Metadata cannot be accessed on this instance"
      throw
    }

    $request = Get-Metadata -UrlFragment "meta-data/elastic-gpus/associations/"

    if ($null -eq $request)
    {
      Write-Log "EG is not available on this instance"
      return $null
    }

    $egpu = $request.Split("\r\n")[0]

    $egpuInfo = Get-Metadata -UrlFragment "meta-data/elastic-gpus/associations/$egpu"
    $json = ConvertFrom-Json $egpuInfo
    $proxy = "http://$($json.connectionConfig.ipv4Address):$($json.connectionConfig.port)"

    $versionsJson = Send-HttpPostJson "http://gam:8080/gam/rest/versions" $proxy "{}"
    $downloadUrl = (ConvertFrom-Json $versionsJson).components[0].Path

    $guid = [System.Guid]::NewGuid().ToString("N")
    $file = "$env:temp\egaim_$guid.msi"
    $logfile = "$env:temp\egaim_$guid.log"

    $downloadSuccess = Get-HttpBinaryFile http://gam:8080/$downloadUrl $proxy $file

    if ($downloadSuccess -eq $false)
    {
      Write-ErrorLog "Download failed"
      throw
    }

    $signatureValid = Test-CertificateIsAws $file

    if ($signatureValid)
    {
      $p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$file`" /qn /log `"$logfile`"" -Wait -PassThru
      if (0 -ne $p.ExitCode) {
        Write-ErrorLog -Message "EGPU installer exited with a non-zero exit code '$($p.ExitCode)'."
      }
    }
    else
    {
      Write-ErrorLog "Signature is not valid"
    }

    $installedVer = Get-EgpuSoftwareVersion "EC2ElasticGPUs_Manager"

    if (($installedVer -eq "") -or ($null -eq $installedVer))
    {
      Write-ErrorLog "ElasticGPUs installation failed ?"
    }

    Write-Log "Installed ElasticGPUs manager $installedVer"

    Remove-Item $file
  }
  catch
  {
    Write-ErrorLog "Error installing eGPU"
  }
}

# SIG # Begin signature block
# MIIurgYJKoZIhvcNAQcCoIIunzCCLpsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCYz4ho+3oBPaJh
# A3+dI1QZ/FpSgbTcVlcMz3DPKC3zq6CCE+MwggXAMIIEqKADAgECAhAP0bvKeWvX
# +N1MguEKmpYxMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMjIwMTEz
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBZjCCAWIwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUsT7DaQP4v0cB1JgmGggC72NkK8MwDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAC
# hj1odHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJh
# bmNlRVZSb290Q0EuY3J0MEsGA1UdHwREMEIwQKA+oDyGOmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwHAYD
# VR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQELBQADggEBAEHx
# qRH0DxNHecllao3A7pgEpMbjDPKisedfYk/ak1k2zfIe4R7sD+EbP5HU5A/C5pg0
# /xkPZigfT2IxpCrhKhO61z7H0ZL+q93fqpgzRh9Onr3g7QdG64AupP2uU7SkwaT1
# IY1rzAGt9Rnu15ClMlIr28xzDxj4+87eg3Gn77tRWwR2L62t0+od/P1Tk+WMieNg
# GbngLyOOLFxJy34riDkruQZhiPOuAnZ2dMFkkbiJUZflhX0901emWG4f7vtpYeJa
# 3Cgh6GO6Ps9W7Zrk9wXqyvPsEt84zdp7PiuTUy9cUQBY3pBIowrHC/Q7bVUx8ALM
# R3eWUaNetbxcyEMRoacwggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdnMIIFT6ADAgECAhAIaSgnopDAtpU2nRSjj8m1MA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjUwODA0MDAwMDAwWhcNMjYwODAzMjM1OTU5WjCB7zET
# MBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQxNTI5NTQx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdTZWF0
# dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMRAwDgYDVQQL
# EwdBV1MgRUMyMSIwIAYDVQQDExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMIIB
# ojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA09z6LRLZ6B29Vw2rlhoClpGs
# KaHQgVSWBiQsZoosPwxMx7nOp3AC4aRP4V7v8E8e1zmzvevPdVL/p9KSPvFz4ApF
# Lt4c5xDryw+bn053Dy6eiKvmiOetjTuP/3b49H4R6kt8LZ8x5KhaphgypeIHKQHC
# 3JrfDjCq3Zh+WYMvL5O2fwcaMQQunl1AiXXKAfahflmC2r0GYzNthvqXvBkfAs9F
# e6ivOSLGVxrtptGveY8omIrde1vVFWItRww+Lk1yxXN5zO28M5SsDMJ5eryZPQ3y
# CWc0722z2GJJ7horCYpWqz9swuVd/YArwtk/Fmbwr8K+A7ZIbM0dLHPx20K3+r/n
# dNyO0gd0G8HGEMbTuE8zG0gPcOLn8faWM7W1pMmkiuOL8WUa2B/Pd0xJw5WinHhj
# FEyGB3LKPEZbxa/IIfHcbqPNE9tLJYJWZ9t9Cg10fECSJ+xsNEeLwerLkZaEzs/H
# fimTNMa/5SuWjCES/e3QUOIm2kg1TO7mXSdAljhtAgMBAAGjggICMIIB/jAfBgNV
# HSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQU6KNonE+tTU2/
# W3Q6S4Ynvfd8w3IwPQYDVR0gBDYwNDAyBgVngQwBAzApMCcGCCsGAQUFBwIBFhto
# dHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5
# NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIx
# Q0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFx4M
# +HScolpI7T6bQYaAO4SU9rP1qiJxBSzEZ7j9rr0Jv3qdBm0SF7iB5NMBmgAKFRnn
# Wb0D46Da1q4hKlC4b9GX7oO6DLiA4b6upXn4ARULR8B+zMaC3PIXLemcnu1ENkj4
# UeFzIaxPbpeT5mNUT8D5dWDsO4L712KN0gkbtt+rwF5cowDuv6ei1A17HHkPPP1D
# KELMP2u5CGrjn67HuNv6n4+gHJW1CP0NSCyB2LpEZf/2FFiqfz4cpCYh6S81/ziA
# cvchuWGSxNpcGRmZFwAcd7wQcNveTJW9YE0JIJApE/q7EsLmk2pyYk02beNXedRN
# fVE7HMLb9ll706RZT93oMdJpfKVHq1qCLsIz/CChcBd4mHsStvxtj9cVCTlE7ELw
# g44I0sZQ+AITXgon+86fyjEM1G4SsZWcnhu8A9U2QzsfvD8vCkuHi3CnEeztf/u2
# 87tzprVnbz0/Y+DmOetj+CmdzNR0949irc10C2ikfK6dWt5r46bzHNYnHEhTVafX
# HL6zHhjOO4liSDb9yP4085xWnjAn4i0NpvL3uHb3Q4NrTrjJQtekVpIBbPuPsF4w
# a/uGLkDjeqjU3CJ9BifbYXHYZNw4ZJz+l5VGFU7RlABPgUIj4Fmac0ZnmbRemFQ8
# I3WQSlfftfuWwHUJ0NkQ/kEl47ZXRNyVfVEuLDYxghohMIIaHQIBATB9MGkxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGln
# aUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAy
# MSBDQTECEAhpKCeikMC2lTadFKOPybUwDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEE
# AYI3AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQghiLgC3heZaRAXRGU
# 4MJGL1xw/Eb8do+32Yqfdavp5OcwDQYJKoZIhvcNAQEBBQAEggGATSl9om40VcAL
# t8GYHbieKLeNLNboMIhqATfZLGm6Yh724l2cbywMOll+tmPQgiIiRukNuvL9HpDs
# 1IqpkVzyj/kMruIVznbo/OTQaG2oZLvKXS9C1ex75VEvO4cAmnZB51V8kySVQ7oE
# f4i7nMSdgXzUz/L3cWqRMVyfFWwy3WGZCGXvzVvFJ1oKzEi+tO39bcgc1JjclxB3
# 5C20iONuAwcL+0F1gNVNUgmR9ra9J4aqCUCI8YNaaBKd1RCy+7/ZNIjKdFpTsyAl
# t8L/J7lhsYOKBFBPXilcBnWKJxRld9iQDz+oHe4rncxCCFB9UOsca5FpC4f9LjNN
# CjAST48i/KEbbUBmcPEIn+xVnin82hHlsq3kx6eLU4cWC5OyJiXOKhlHaD0yuLG1
# YuIEHD/HgB3V8MHQMV5zTHgnbpY2ZhCwxlN2ewvsc2x6S+FsTcX/EKHwBfMzs5Nx
# t7k66aTgTNj0iyIgNWhoJ9GP730Q+Ib72CW7OxaBs5/XFj/loHtaoYIXdzCCF3MG
# CisGAQQBgjcDAwExghdjMIIXXwYJKoZIhvcNAQcCoIIXUDCCF0wCAQMxDzANBglg
# hkgBZQMEAgEFADB4BgsqhkiG9w0BCRABBKBpBGcwZQIBAQYJYIZIAYb9bAcBMDEw
# DQYJYIZIAWUDBAIBBQAEICaCEi5UfI8XcD1wzY8zzKKbJAPYd1+4IjzTaKJRWgEt
# AhEAw2zky2AUvu2wxIDh/4Nv8RgPMjAyNTEwMTMwNTIwNTVaoIITOjCCBu0wggTV
# oAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENB
# MTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgU0hB
# MjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwtEsae0OquYFazK1e6b1H/hnAKAd/K
# N8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjni6bz52fGTfr6PHRNv6T7zsf1Y/E3
# IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EIYLkrLKd6qJnuzK8Vcn0DvbDMemQF
# oxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytxNM89PZXUP/5wWWURK+IfxiOg8W9l
# KMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6EYevvOi7XOc4
# zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Oskkkrvt6lPAw/p4oDSRZreiwB7x9y
# krjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw4Smz8U07hqF+
# 8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrAtuvz0D3T+dYaNcwafsVCGZKUhQPL
# 1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi54wm0i2ePZD5pPIssoszQyF4//3D
# oK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJYi+6I03UuT1j7FnrqVrOzaQoVJOee
# StPeldYRNMmSF3voIgMFtNGh86w3ISHNm0IaadCKCkUe2LnwJKa8TIlwCUNVwppw
# n4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQU5Dv8
# 8jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgwFoAU729TSunkBnx6yuKQVvYv1Ens
# y04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIGVBggr
# BgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5j
# cnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEu
# Y3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0B
# AQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNAciH45PYiT9s1i6UKtW+FERp8FgXR
# GQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PCvHpQuPqFgqp1
# PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5qjzvZs7JIIgt0GCFD9ktx0LxxtRQ
# 7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kzekd8oEARzFAWgeW3az2xejEWLNN4e
# KGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE2oi0fcI8VMbt
# oRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLhAezu/3Lr00Gr
# JzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2/gTlQJINqDr6
# JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCyIaehr0XkBoDI
# GMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53VJUNOaMWMts0VlRYxe5nK+At+DI96
# HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yERNpbJCjyCYG2j+bdpxo/1Cy4uPcU3
# AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3zWcwgga0MIIE
# nKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNV
# BAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdp
# Y2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0y
# NTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYD
# VQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBH
# NCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51N
# rY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5ba
# p+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf7
# 7S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF
# 2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80Fio
# cSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzV
# yhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl
# 92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGP
# RdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//
# Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4O
# Lu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM
# 7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# ABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM
# 0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqW
# Gd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr
# 0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35
# k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKq
# MVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiy
# fTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDU
# phPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTj
# d6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2Z
# yJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWC
# nb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZPubdcMIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDfDCCA3gCAQEwfTBpMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0
# ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAKgO8Y
# S43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsq
# hkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjUxMDEzMDUyMDU1WjArBgsqhkiG
# 9w0BCRACDDEcMBowGDAWBBTdYjCshgotMGvaOLFoeVIwB/tBfjAvBgkqhkiG9w0B
# CQQxIgQgUb72MntDLT4Z42juFnOi0+OIIxKOsNmit+//fsZu0gEwNwYLKoZIhvcN
# AQkQAi8xKDAmMCQwIgQgSqA/oizXXITFXJOPgo5na5yuyrM/420mmqM08UYRCjMw
# DQYJKoZIhvcNAQEBBQAEggIAK6PApH0ZpvNUb1XjsWSgIAkB8pLTIGdaEbjPp/3H
# HNJJJV4yYhUHwpCtGtONewFLoiFksbZ5K4OFvOyipj6oI4pHi12TIxcS5IQVJCYO
# UeXbDLxgHPV4LBHyeWNDDP4b27vzoN+OLg3gNDdSUcTpcouTr3knHU6RSTRQG4e8
# Xq6JY1IInczaxy+b+GR4/8zQ8WaIluiPb7sUCoqTf5NQ1Fqjkmmw0bDkhfkk/Joz
# VX+GmIebZ9/S+mohZyoEG5VEiUVtxY2Gmku5oDjXLXfirPkxaOFpEubZyoGxSeco
# 5V5FyoG6T3AKjKLJxBNiy2XfTg3b8srsaYtW9NKBopMluaWz8mZ/m4IardDzZU/5
# sCIDgLcw8eCbwZeAg1LBkW9GyAkkavNsPKDmpYhzNd0ktqoTv7MmIYQm8MqgCDtt
# ghkWQ+rbzo2QKw8LeId9SIhQlA0N8SzJlYtBvIycCPj+lQF74NMwQYh8QZpuEm7+
# EdFiWFVfT3xbKhCsjoJeAIMJP0JOfMhrldI2V3V45RI7OPmI/YlAS51G6aIKoH1W
# NOYerMyVrIS+5Kgwba80L1WbqtVnzBEVz6gLb+ZgmN0dneWZHYXVotPDDU6VDKch
# mplq+8pUa7QIG7RMzhDTXNVZvKXCgfukhlDXLdyT2ZEaYf2+TqJe4Y92qqgRM1M+
# Rko=
# SIG # End signature block
