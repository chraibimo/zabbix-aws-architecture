History

Changes in latest
===============
- Updated agent log messaging.

Changes in 1.3.2005119
===============
- Fixed an issue where Invoke-Userdata would fail when called without any parameters.

Changes in 1.3.2005065
===============
- Fixed an issue where RDP certificate information was not properly retrieved or validated. Added functionality to automatically start the Remote Desktop Services if needed.

Changes in 1.3.2005008
===============
- Updated Set-Wallpaper to fall back to a solid color background if the default wallpaper image is not found.

Changes in 1.3.2004959
===============
- Updated installer logic to prevent unsupported installation on Windows Server 2025 or later.
- Modified EC2Launch permissions.

Changes in 1.3.2004891
===============
- Fixed an issue where HandleUserData was not set to false as expected.
- Added an 'Encrypted' password option to LaunchConfig.json.
- Changed Settings UI behavior to encrypt the user specified password by default.
- Added SetAdminPasswordConfig.ps1 to convert the 'Specify' password option to the 'Encrypted' password option in the agent configuration file.

Changes in 1.3.2004617
===============
- Fixed an error when setting the wallpaper.

Changes in 1.3.2004592
===============
- Update access permissions set by install.ps1 for %ProgramData%\Amazon\EC2-Windows\Launch.
- Restricted EC2Launch folder/file access to read-execute only for standard user accounts.
- Changed the agent to stop waiting for the Instance Metadata Service (IMDS) to initialize if IMDS is not enabled for the instance.
- Added a 5 minute timeout when waiting for the Instance Metadata Service (IMDS) to initialize.
- Changed the agent to write telemetry to the instance console log before the 'Windows is Ready' message instead of after.
- Added wallpaper support to several new instance types

Changes in 1.3.2004491
===============
- Added telemetry to monitor usage of the Specify admin password option.

Changes in 1.3.2004462
===============
- Added flush after every write to the serial console.

Changes in 1.3.2004438
===============
- Limit domain name devolution based on registry entry: HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Dnscache\Parameters\DomainNameDevolutionLevel.
- Limited UserdataExecution.log permissions to Administrators only.
- Added error messages in the Windows Event Log when log initialization fails.

Changes in 1.3.2004256
===============
- Added EnableSCSIPersistentReservations value to console log.
- Added retry capability for Get-ConsolePort.

Changes in 1.3.2004052
===============
- Fixed an error when no SSH key is specified at instance launch.
- Retry starting the AmazonSSMAgent Windows service on failure.
- Fail SysprepInstance.ps1 if BeforeSysprep.cmd fails with a non-zero exit code.

Changes in 1.3.2003975
===============
- Fixed an issue impacting Packer AMI builds where SysprepInstance.ps1 returns a $LastErrorCode of 1.

Changes in 1.3.2003961
===============
- Fixed issue where explicitly specified Administrator passwords were overwritten with a random password on fast-launched instances.
- Fixed issue where SSM Agent fails to start on low-specification instance types.
- Fixed an issue where the instance console log contains 'RDPCERTIFICATE-THUMBPRINT: 00000000000000000000000' instead of a valid RDP certificate thumbprint value.

Changes in 1.3.2003923
===============
- Fixes logic for finding network adapter when PnPDeviceID is empty

Changes in 1.3.2003919
===============
- Updated Get-ConsolePort to use PCI segment information.
- Fixed issue where an incorrect network adapter can be selected after a reboot.
- Fixed start-SSM-Agent timeout logic.
- Fixed Send-AdminCredentials function alias backwards compatibility.

Changes in 1.3.2003857
===============
- Prioritize adapters with a default gateway when selecting the primary network adapter.
- Extended in-memory password encryption.

Changes in 1.3.2003824
===============
- Fixed error during set computer name.
- Added logic to skip Windows activation if a BYOL billing code is detected.
- Added in-memory password encryption.
- Fixed error during initialize volume on m6id.4xlarge.

Changes in 1.3.2003691
===============
- Updated IMDS wait logic to make only IMDSv2 requests.
- Fixed bug impacting eGPU installation.

Changes in 1.3.2003639
===============
- Added network-adapter wait logic to prevent use before initialization.
- Fixed minor issues.

Changes in 1.3.2003498
===============
- Added telemetry
- Added shortcut to settings UI
- Formatted PowerShell scripts
- Fixed bug that shutdown does not wait for BeforeSysprep.cmd to complete

Changes in 1.3.2003411
===============
- Changed password generation logic to exclude passwords with low complexity

Changes in 1.3.2003364
===============
- Update Install-EgpuManager with IMDS V2 support

Changes in 1.3.2003312
===============
- Added log lines before and after setting monitor always on
- Added AWS Nitro enclaves package version to console log

Changes in 1.3.2003284
===============
- Improved permission model by updating location for storing user data to LocalAppData

Changes in 1.3.2003236
===============
- Update method for setting user password in Set-AdminAccount and Randomize-LocalAdminPassword
- Fix InitializeDisks to check if disk is set to read only before setting it to writable

Changes in 1.3.2003210
===============
- Localization fix for install.ps1

Changes in 1.3.2003205
================
- Security fix for install.ps1 to update permissions on %ProgramData%\Amazon\EC2-Windows\Launch\Module\Scripts directory

Changes in 1.3.2003189
================
- Add w32tm resync after adding routes

Changes in 1.3.2003155
================
- Update instance types information

Changes in 1.3.2003150
================
- Add OsCurrentBuild and OsReleaseId to console output

Changes in 1.3.2003040
================
- Fixed IMDS V1 fallback logic

Changes in 1.3.2002730
================
- Add support for IMDS V2

Changes in 1.3.2002240
================
- Fixed minor issues.

Changes in 1.3.2001660
================
- Fixed automatic login issue of passwordless user after first time of executing Sysprep.

Changes in 1.3.2001360
================
- Fixed minor issues.

Changes in 1.3.2001220
================
- All PowerShell scripts are signed.

Changes in 1.3.2001200
================
- Fix issue with InitializeDisks.ps1 where running the script on a node in a Microsoft Windows Server Failover Cluster would format drives on remote nodes whose drive letter matches the local drive letter

Changes in 1.3.2001160
================
- Fix missing wallpaper on Windows 2019

Changes in 1.3.2001040
================
- Add plugin for setting the monitor to never turn off to fix acpi issues
- Write sql server edition and version to console

Changes in 1.3.2000930
===============
- Fix for adding routes to metadata on ipv6 enabled ENIs

Changes in 1.3.2000760
================
- Add default configuration for RSS and Receive Queue settings for ENA devices
- Disable hibernation during sysprep

Changes in 1.3.2000630.0
================
- Added route 169.254.169.253/32 for DNS server
- Added filter of setting Admin user
- Improvements made to instance hibernation
- Added option to schedule EC2Launch to run on every boot

Changes in 1.3.2000430.0
================
- Added route 169.254.169.123/32 to AMZN time service
- Added route 169.254.169.249/32 to GRID license service
- Added timeout of 25 seconds when attempting to start SSM

Changes in 1.3.200039.0
================
- Fix improper drive lettering for EBS NVME volumes
- Added additional logging for NVME driver versions

Changes in 1.3.2000080
================

Changes in 1.3.610
================
- Fixed issue with redirecting output and errors to files from user data.

Changes in 1.3.590
================
- Added missing instances types in the wallpaper.
- Fixed an issue with drive letter mapping and disk installation.

Changes in 1.3.580
================
- Fixed Get-Metadata to use the default system proxy settings for web requests.
- Added a special case for NVMe in disk initialization.
- Fixed minor issues.

Changes in 1.3.550
================
- Added a -NoShutdown option to enable Sysprep with no shutdown.

Changes in 1.3.540
================
- Fixed minor issues.

Changes in 1.3.530
================
- Fixed minor issues.

Changes in 1.3.521
================
- Fixed minor issues.

Changes in 1.3.0
================
- Fixed a hexadecimal length issue for computer name change.
- Fixed a possible reboot loop for computer name change.
- Fixed an issue in wallpaper setup.

Changes in 1.2.0
================
- Update to display information about installed operating system (OS) in EC2 system log.
- Update to display EC2Launch and SSM Agent version in EC2 system log.
- Fixed minor issues.

Changes in 1.1.2
================
- Update to display ENA driver information in EC2 system log.
- Update to exclude Hyper-V from primary NIC filter logic.
- Added KMS server and port into registry key for KMS activation.
- Improved wallpaper setup for multiple users.
- Update to clear routes from persistent store.
- Update to remove the z from availability zone in DNS suffix list.
- Update to address an issue with the <runAsLocalSystem> tag in user data.

Changes in 1.1.1
================
- Initial release.
